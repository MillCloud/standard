# google-access-helper
<p align="center"><img width="15%" src="./logo.png" /></p>
<h1 align="center">谷歌访问助手</h1>

**本软件已破解，可永久免费使用！**

## 安装说明

由于新版本Chrome已禁止安装第三方应用，且本破解版无法上传至[Chrome网上应用店](https://chrome.google.com/webstore)，因此只能通过以下方法在开发者模式下运行：

1. 克隆仓库: [点击下载](https://codeload.github.com/KimGuBa/google-access-helper/zip/master) 下载完文件后后解压
2. 解压后根目录下可用的文件
```
├── google-access-helper-2.3.0
├── google-access-helper-2.3.0.crx
├── igg_install_iGuge引导安装包
├── README.md
```
+ 可用的文件有
    + `google-access-helper-2.3.0.crx` 文件
    + `google-access-helper-2.3.0` 目录
    + `igg_install_iGuge引导安装包` 目录

3. 打开Chrome扩展程序管理器 `chrome://extensions`
4. 勾选 `开发者模式`
5. 点击 `加载已解压的扩展程序`，选择 `步骤2` 所提到的`文件或目录`(挑选一个就行)拖进扩展管理器即可

## 破解说明
- 直接对js文件修改删除保留翻墙功能，本破解版已精简
